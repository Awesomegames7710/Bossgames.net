var langs = {
	'de':'deutsch',
	'el':'ελληνικά',
	'en':'english',
	'es':'español',
	'fr':'français',
	'id':'bahasa indonesia',
	'it':'italiano',
	'lv':'latviešu valoda'
	'ja':'日本語',
	'ko':'한국어',
	'nb':'norsk',
	'pl':'polski',
	'pt':'português',
	'pt_br':'português (brasil)',
	'ru':'русский',
	'sv':'svenska',
	'th':'ไทย',
	'tr':'türkçe',
	'uk':'українська',
	'vi':'tiếng việt',
	'zh_cn':'简体中文',
	'zh_tw':'繁體中文'
};
